#!/usr/bin/env python
from mininet.net import Mininet
from mininet.node import RemoteController
from mininet.topo import Topo
# For VLAN
from mininet.cli import CLI
from mininet.node import Link, Host
from mininet.term import makeTerm
from functools import partial
# For Optical Networks
from opticalUtils import MininetOE, LINCSwitch, LINCLink
from mininet.log import setLogLevel

class ChiragCustomTopo( Topo ):

    def build( self ):
        ''' Creating the optical switches '''
        print 'Emulating the Network'
        print 'Creating Optical Networks'

        o1ann = { "latitude": 45, "longitude": -110, "optical.regens": 0 }
        O1 = self.addSwitch( 'ROADM1', dpid='0000ffffffffff01', annotations=o1ann, cls=LINCSwitch )

        o2ann = { "latitude": 40, "longitude": -110, "optical.regens": 3 }
        O2 = self.addSwitch( 'ROADM2', dpid='0000ffffffffff02', annotations=o2ann, cls=LINCSwitch )

        o3ann = { "latitude": 45, "longitude": -105, "optical.regens": 3 }
        O3 = self.addSwitch( 'ROADM3', dpid='0000ffffffffff03', annotations=o3ann, cls=LINCSwitch )

        o4ann = { "latitude": 43, "longitude": -105, "optical.regens": 3 }
        O4 = self.addSwitch( 'ROADM4', dpid='0000ffffffffff04', annotations=o4ann, cls=LINCSwitch )

        o5ann = { "latitude": 45, "longitude": -100, "optical.regens": 0 }
        O5 = self.addSwitch( 'ROADM5', dpid='0000ffffffffff05', annotations=o5ann, cls=LINCSwitch )

        o6ann = { "latitude": 40, "longitude": -100, "optical.regens": 0 }
        O6 = self.addSwitch( 'ROADM6', dpid='0000ffffffffff06', annotations=o6ann, cls=LINCSwitch )

        ''' Creating the IP Switches '''

        # Creating the IP Layer for Company F
        print 'Creating IP Layer'

        F_sw1 = self.addSwitch( 'Fsw1', dpid='0000ffffffff0001', annotations={ "latitude": 42.5, "longitude": -109} )
        F_sw2 = self.addSwitch( 'Fsw2', dpid='0000ffffffff0002', annotations={ "latitude": 43.5, "longitude": -109.3} )
        F_sw3 = self.addSwitch( 'Fsw3', dpid='0000ffffffff0003', annotations={ "latitude": 44.5, "longitude": -109} )
        F_sw4 = self.addSwitch( 'Fsw4', dpid='0000ffffffff0004', annotations={ "latitude": 42.5, "longitude": -111} )
        F_sw5 = self.addSwitch( 'Fsw5', dpid='0000ffffffff0005', annotations={ "latitude": 43.5, "longitude": -110.7} )
        F_sw6 = self.addSwitch( 'Fsw6', dpid='0000ffffffff0006', annotations={ "latitude": 44.5, "longitude": -111} )
        # Creating Hosts
        # This is for Vlan: h13 = self.addHost('A-h1', cls=VLANHost, vlan=100, mac='00:00:00:00:00:13')
        h1 = self.addHost('Fh1', mac='00:00:00:00:00:01', annotations={ "latitude": 42.5, "longitude": -109} )
        h2 = self.addHost('Fh2', mac='00:00:00:00:00:02', annotations={ "latitude": 43.5, "longitude": -109} )
        h3 = self.addHost('Fh3', mac='00:00:00:00:00:03', annotations={ "latitude": 44.5, "longitude": -109} )
        h4 = self.addHost('Fh4', mac='00:00:00:00:00:04', annotations={ "latitude": 42.5, "longitude": -111} )
        h5 = self.addHost('Fh5', mac='00:00:00:00:00:05', annotations={ "latitude": 43.5, "longitude": -111} )
        h6 = self.addHost('Fh6', mac='00:00:00:00:00:06', annotations={ "latitude": 44.5, "longitude": -111} )
        print 'Company F done...'

        # Creating the IP Layer for Company M
        M_sw1 = self.addSwitch( 'Msw1', dpid='0000ffffffff0007', annotations={"latitude": 42.5, "longitude": -99})
        M_sw2 = self.addSwitch( 'Msw2', dpid='0000ffffffff0008', annotations={"latitude": 43.5, "longitude": -99.3})
        M_sw3 = self.addSwitch( 'Msw3', dpid='0000ffffffff0009', annotations={"latitude": 44.5, "longitude": -99})
        M_sw4 = self.addSwitch( 'Msw4', dpid='0000ffffffff0010', annotations={"latitude": 42.5, "longitude": -101})
        M_sw5 = self.addSwitch( 'Msw5', dpid='0000ffffffff0011', annotations={"latitude": 43.5, "longitude": -100.7})
        M_sw6 = self.addSwitch( 'Msw6', dpid='0000ffffffff0012', annotations={"latitude": 44.5, "longitude": -101})
        # Creating Hosts
        h8 = self.addHost('Mh2', mac='00:00:00:00:00:08', annotations={"latitude": 42.5, "longitude": -99})
        h7 = self.addHost('Mh1', mac='00:00:00:00:00:07', annotations={"latitude": 43.5, "longitude": -99})
        h9 = self.addHost('Mh3', mac='00:00:00:00:00:09', annotations={"latitude": 44.5, "longitude": -99})
        h10 = self.addHost('Mh4', mac='00:00:00:00:00:10', annotations={"latitude": 42.5, "longitude": -101})
        h11 = self.addHost('Mh5', mac='00:00:00:00:00:11', annotations={"latitude": 43.5, "longitude": -101})
        h12 = self.addHost('Mh6', mac='00:00:00:00:00:12', annotations={"latitude": 44.5, "longitude": -101})
        print 'Company M done...'

        # Creating the IP Layer for Company Z
        Z_sw1 = self.addSwitch( 'Zsw1', dpid='0000ffffffff0013', annotations={"latitude": 39.5, "longitude": -99})
        Z_sw2 = self.addSwitch( 'Zsw2', dpid='0000ffffffff0014', annotations={"latitude": 38.5, "longitude": -99.3})
        Z_sw3 = self.addSwitch( 'Zsw3', dpid='0000ffffffff0015', annotations={"latitude": 37.5, "longitude": -99})
        Z_sw4 = self.addSwitch( 'Zsw4', dpid='0000ffffffff0016', annotations={"latitude": 39.5, "longitude": -101})
        Z_sw5 = self.addSwitch( 'Zsw5', dpid='0000ffffffff0017', annotations={"latitude": 38.5, "longitude": -100.7})
        Z_sw6 = self.addSwitch( 'Zsw6', dpid='0000ffffffff0018', annotations={"latitude": 37.5, "longitude": -101})

		# Creating Hosts
        h13 = self.addHost('Zh1', mac='00:00:00:00:00:13', annotations={"latitude": 39.5, "longitude": -99})
        h14 = self.addHost('Zh2', mac='00:00:00:00:00:14', annotations={"latitude": 38.5, "longitude": -99})
        h15 = self.addHost('Zh3', mac='00:00:00:00:00:15', annotations={"latitude": 37.5, "longitude": -99})
        h16 = self.addHost('Zh4', mac='00:00:00:00:00:16', annotations={"latitude": 39.5, "longitude": -101})
        h17 = self.addHost('Zh5', mac='00:00:00:00:00:17', annotations={"latitude": 38.5, "longitude": -101})
        h18 = self.addHost('Zh6', mac='00:00:00:00:00:18', annotations={"latitude": 37.5, "longitude": -101})

        print 'Company Z done...'

        ''' Creating the links for optical layer '''

        self.addLink( O1, O2, port1=30, port2=20, annotations={ "durable": "true" }, cls=LINCLink )
        self.addLink( O1, O3, port1=20, port2=20, annotations={ "durable": "true" }, cls=LINCLink )
        self.addLink( O2, O4, port1=30, port2=20, annotations={ "durable": "true" }, cls=LINCLink )
        self.addLink( O2, O6, port1=40, port2=20, annotations={ "durable": "true" }, cls=LINCLink )
        self.addLink( O3, O5, port1=30, port2=40, annotations={ "durable": "true" }, cls=LINCLink )
        self.addLink( O4, O5, port1=30, port2=30, annotations={ "durable": "true" }, cls=LINCLink )
        self.addLink( O5, O6, port1=20, port2=30, annotations={ "durable": "true" }, cls=LINCLink )
        print 'Optical Layer Links Created'

        ''' Connecting the IP Switches to the optical WDM'''

        # For company F
        self.addLink( F_sw3, O1, port1=10, port2=10, speed1=10000, annotations={ "bandwidth": 100000, "durable": "true" }, cls=LINCLink )
        self.addLink( F_sw4, O1, port1=10, port2=11, speed1=10000, annotations={ "bandwidth": 100000, "durable": "true" }, cls=LINCLink )

        # For Company M
        self.addLink( M_sw3, O5, port1=10, port2=10, speed1=10000, annotations={ "bandwidth": 100000, "durable": "true" }, cls=LINCLink )
        self.addLink( M_sw4, O5, port1=10, port2=11, speed1=10000, annotations={ "bandwidth": 100000, "durable": "true" }, cls=LINCLink )

        # For Company Z
        self.addLink( Z_sw1, O6, port1=10, port2=10, speed1=10000, annotations={ "bandwidth": 100000, "durable": "true" }, cls=LINCLink )
        self.addLink( Z_sw3, O6, port1=10, port2=11, speed1=10000, annotations={ "bandwidth": 100000, "durable": "true" }, cls=LINCLink )




        ''' Setting up the Network inside each company '''
        # Company F
        print ' Setting up Company F '
        # Connecting hosts to the Switches
        self.addLink(F_sw1, h1, port1=1)
        self.addLink(F_sw2, h2, port1=1)
        self.addLink(F_sw3, h3, port1=1)
        self.addLink(F_sw4, h4, port1=1)
        self.addLink(F_sw5, h5, port1=1)
        self.addLink(F_sw6, h6, port1=1)
        # Connecting the switches in the Network
        self.addLink(F_sw1, F_sw6)    # link 1
        self.addLink(F_sw2, F_sw5)    # link 2
        self.addLink(F_sw3, F_sw4)    # link 3
        self.addLink(F_sw1, F_sw3)    # link 4
        self.addLink(F_sw6, F_sw4)    # link 5
        self.addLink(F_sw1, F_sw2)    # link 6
        self.addLink(F_sw2, F_sw3)    # link 7
        self.addLink(F_sw6, F_sw5)    # link 8
        self.addLink(F_sw5, F_sw4)    # link 9

        # Company M
        print ' Setting up Company M '

        # Connecting hosts to the Switches
        self.addLink(M_sw1, h7, port1=1)
        self.addLink(M_sw2, h8, port1=1)
        self.addLink(M_sw3, h9, port1=1)
        self.addLink(M_sw4, h10, port1=1)
        self.addLink(M_sw5, h11, port1=1)
        self.addLink(M_sw6, h12, port1=1)
        # Connecting the switches in the Network
        self.addLink(M_sw1, M_sw6)    # link 1
        self.addLink(M_sw2, M_sw5)    # link 2
        self.addLink(M_sw3, M_sw4)    # link 3
        self.addLink(M_sw1, M_sw3)    # link 4
        self.addLink(M_sw6, M_sw4)    # link 5
        self.addLink(M_sw1, M_sw2)    # link 6
        self.addLink(M_sw2, M_sw3)    # link 7
        self.addLink(M_sw6, M_sw5)    # link 8
        self.addLink(M_sw5, M_sw4)    # link 9

        # Company Z
        print ' Setting up Company Z '
        # Connecting hosts to the Switches
        self.addLink(Z_sw1, h13, port1=1)
        self.addLink(Z_sw2, h14, port1=1)
        self.addLink(Z_sw3, h15, port1=1)
        self.addLink(Z_sw4, h16, port1=1)
        self.addLink(Z_sw5, h17, port1=1)
        self.addLink(Z_sw6, h18, port1=1)
        # Connecting the switches in the Network
        self.addLink(Z_sw1, Z_sw6)    # link 1
        self.addLink(Z_sw2, Z_sw5)    # link 2
        self.addLink(Z_sw3, Z_sw4)    # link 3
        self.addLink(Z_sw1, Z_sw3)    # link 4
        self.addLink(Z_sw6, Z_sw4)    # link 5
        self.addLink(Z_sw1, Z_sw2)    # link 6
        self.addLink(Z_sw2, Z_sw3)    # link 7
        self.addLink(Z_sw6, Z_sw5)    # link 8
        self.addLink(Z_sw5, Z_sw4)    # link 9


if __name__ == '__main__':

    import sys
    if len( sys.argv ) >= 2:
        controllers = sys.argv[1:]
    else:
        print 'Usage:sudo -E python ChiragCustom.py (<Controller IP>)+'
        print 'Using localhost...\n'
        controllers = [ '127.0.0.1' ]

    setLogLevel( 'info' )
    net = MininetOE( topo=ChiragCustomTopo(), controller=None, autoSetMacs=True )
    net.addControllers( controllers )
    net.start()
    CLI( net )
    net.stop()

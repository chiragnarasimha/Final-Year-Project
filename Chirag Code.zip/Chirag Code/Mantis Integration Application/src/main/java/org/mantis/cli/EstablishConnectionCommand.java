package org.mantis.cli;

import org.apache.karaf.shell.commands.Argument;
import org.apache.karaf.shell.commands.Command;
import org.apache.karaf.shell.commands.Option;
import org.onosproject.cli.AbstractShellCommand;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

// import org.mantis.MantisApplication;
// import org.mantis.TopologyManager;


@Command(scope = "mantis", name = "mantis-establish-connection", description = "This command will allow ONOS to establish connection with Mantis.")

public class EstablishConnectionCommand extends AbstractShellCommand {


    // It is not necessary to type in the url. Use this option only when the ip address of Mantis has changed.
    @Option(name = "url", description = "Mantis URL. Use this option when Mantis url has changed.", required = false, multiValued = false)
    String url = null;

    // This command will allow the user to input the local of the file with the static paramaters for Mantis.
    @Argument(index = 0, name = "data", description = "Json data file", required = true, multiValued = false)
    String dataStr = null;


    @Override
    protected void execute() {
        // Mantis currently does not have support for get requests

        // Checking if the user has entered the url of Mantis.
        String rest_service_url;

        // print("test");

        if ( url == null )
            {
              // print("The Default url is used");
              rest_service_url = "http://147.102.22.142:8080/static_parameters";
            }
        else
            rest_service_url = url + "/static_parameters";

        if ( dataStr == null ) {
          print("Error: JSON File Invalid");
          return;
        }


        try {



            String request_params = new String(Files.readAllBytes(Paths.get(dataStr)));


            Client client = ClientBuilder.newClient();

            WebTarget myResource = client.target(rest_service_url);

            Response response = myResource.request(MediaType.APPLICATION_JSON).post(Entity.json(request_params));

            print("Response =>  %s - %s", response.getStatus(), response.getStatusInfo().getReasonPhrase());

            response.close();
        }
        // Error Reporting
        catch (IOException e){
            error("\nUnable to read input JSON data file. \n");
        }

    }
}

/*
*****************These are some of the old debugging code.**********************

Client client = ClientBuilder.newClient();
String get_res = client.target("http://147.102.22.142:8080/koko")
        .request(MediaType.APPLICATION_JSON)
        .get(String.class);

print(" --> Dummy GET: %s",get_res);

*/

package org.mantis.cli;

import org.apache.karaf.shell.commands.Argument;
import org.apache.karaf.shell.commands.Command;
import org.apache.karaf.shell.commands.Option;
import org.onosproject.cli.AbstractShellCommand;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;


@Command(scope = "mantis", name = "mantis-qot-analysis", description = "QoT analysis for established optical connections")
public class QotAnalysisCommand extends AbstractShellCommand {

    @Option(name = "-url", aliases = "--url", description = "server-url", required = false, multiValued = false)
    String url = null;

    @Argument(index = 0, name = "ids", description = "Connection ids", required = false, multiValued = true)
    String idsStr = null;

    @Override
    protected void execute() {

        String rest_service_url;
        String json_request;

        if ( idsStr == null || idsStr.isEmpty() )
           json_request = "{\"Lightpaths\":[-1]}";
        else
            json_request = "{\"Lightpaths\": "+ idsStr +"}";

        if ( url == null )
            rest_service_url = "http://147.102.22.142:8080/qot_analysis"; /* TODO : Get default from some other source, not hardcode*/
        else
            rest_service_url = url+"/qot_analysis";

        Client client = ClientBuilder.newClient();

        WebTarget myResource = client.target(rest_service_url);

        Response response = myResource.request(MediaType.APPLICATION_JSON).post(Entity.json(json_request));

        String post_res = response.readEntity(String.class);

        print(" --> Dummy POST: %s",post_res);
    }

}

// The code here is written in the same conventions that has been used in the source code of ONOS. This class is different to the original TopologyManager class that is in the ONOS Source Code becaue it is necessary to obtian the topology of the optical layer only.

package org.mantis;

import java.util.*;

// Importing all the libraries to generate the JSONSchema
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.*;
import com.fasterxml.jackson.databind.node.BaseJsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.io.IOException;

// Importing the libraries for multimap array list
import com.google.common.collect.Multimap;
import com.google.common.collect.ArrayListMultimap;

// Importing the libraries to use ONOS internal mechanism to  gather information from ONOS
import org.onosproject.net.Link;
import org.onosproject.net.DeviceId;
import org.onosproject.net.OchSignal;
import org.onosproject.net.Port;
import org.onosproject.net.optical.OchPort;
import org.onosproject.newoptical.OpticalConnectivity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TopologyManager {


    // Creating the logger for this class
    private final Logger log = LoggerFactory.getLogger(getClass());

    // These lists are necessary to retain the following information
    List<String> opticalNodeIds;
    List<OpticalNode> availableOpticalNodes;
    List<Link> availableOpticalLinks;
    List<PacketNode> availablePacketNodes;
    Multimap<String, CrossConnect> opticalNodeCrossConnects;

    // Initialising the class constructor
    public TopologyManager() {

        opticalNodeIds = new ArrayList<>();
        availableOpticalNodes = new ArrayList<>();
        availableOpticalLinks = new ArrayList<>();
        availablePacketNodes = new ArrayList<>();
        opticalNodeCrossConnects = ArrayListMultimap.create();

    }

    public void addOpticalNode(DeviceId id, boolean available) {

        if (!opticalNodeIds.contains(id.toString())) {
            opticalNodeIds.add(id.toString());
            availableOpticalNodes.add(new OpticalNode(id.toString(), available));
        }

    }

    public void removeOpticalNode(DeviceId id) {
        //kane pi8anon packetNode ws mia available
    }


    public void updateOpticalNode(DeviceId id, boolean available) {

    }

    public void handleDeviceOpticalLink(String device_id, Link link) {

        if( checkIfKnownLink(link) )
            return;

        if ( isCrossConnectionLink(link) ) {
            if ( !opticalNodeIds.contains(link.src().deviceId().toString()) )
              return;

            addPacketNode(link.src().deviceId().toString(), link.dst().deviceId().toString());
        }
        else
            availableOpticalLinks.add(link);
    }

    public void handleCrossConnectionsPoints(String device_id, List<Port> ports){

        for (Port port : ports) {

            if ( port instanceof OchPort ) {

                OchPort och = (OchPort) port;

                opticalNodeCrossConnects.put(device_id, new CrossConnect(port, och));
            }

        }
    }

    public void handleEstablishedConnections(Collection<OpticalConnectivity> connections) {

        for (OpticalConnectivity connectivity : connections) {

            log.error(" --> Connectivity: {}", connectivity.id().id());

        }
    }

    // Mantis requires the information to be pushed in JSON format. Option 1 will return all the information that we collect from ONOS. Option 2 will retun the Network_Topology information that Mantis requires.
    public String generateInternalJSONSchema()  {

        String JSONSchema = null;
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode Network_Topology = mapper.createObjectNode();

              try {

                  NetworkTopologyInfo networkTopologyInfo = new NetworkTopologyInfo();
                  networkTopologyInfo.build2();
                  NodesDevicesInfo nodesDevicesInfo = new NodesDevicesInfo();
                  nodesDevicesInfo.build3();
                  EstablishedConnections establishedConnections = new EstablishedConnections();
                  JSONSchema = "{\"Network_Topology\":" + mapper.writeValueAsString(networkTopologyInfo) + ", \"Node_Devices\":" + mapper.writeValueAsString(nodesDevicesInfo) + ", \"Established_Connections\" :" + mapper.writeValueAsString(establishedConnections) + "}";
                  log.info(JSONSchema);

              } catch (JsonProcessingException e) {
                  log.error(" Failed to generate JSONSchema for Network_Topology ");
                  log.error(e.toString());
              }

            return JSONSchema;
    }


    // The following classes are private classes as they are used to obtain info from ONOS to be used in the public classes above.

    private void addPacketNode(String optical_device_id, String packet_device_id){

        if ( availablePacketNodes.stream().filter((p) -> p.id.equals(packet_device_id)).count() == 0 )
            availablePacketNodes.add(new PacketNode(packet_device_id, optical_device_id, true));
    }

    private boolean checkIfKnownLink(Link link){

        if ( availableOpticalLinks.stream().filter((l) -> l.src() == link.src() && l.dst() == link.dst()).count() > 0 )
            return true;
        else
            return false;
    }

    private boolean isCrossConnectionLink(Link link) {

        if( opticalNodeIds.contains(link.src().deviceId().toString()) &&
                opticalNodeIds.contains(link.dst().deviceId().toString()) )
            return false;
        else
            return true;
    }

    // This class is used to get all the optical nodes in the topology
    private class OpticalNode {

        public String id;
        public boolean available;

        OpticalNode(String id, boolean available) {
            this.id = id;
            this.available = available;
        }
    }

    private class PacketNode {

        public String id;
        public String optical_node_id;
        public boolean available;

        PacketNode(String id, String optical_node_id, boolean available) {
            this.id = id;
            this.optical_node_id = optical_node_id;
            this.available = available;
        }
    }

    // This class can be used to get the link between source and destination
    private class TopoLink{

        public List nodes = new ArrayList();
        public double length;
        public boolean available;

        // Class constructors
        TopoLink(String src, String dst, double length, boolean available){
            this.nodes.add(src);
            this.nodes.add(dst);
            this.length = length;
            this.available = available;
        }

        TopoLink(String src, String dst, double length){
            this.nodes.add(src);
            this.nodes.add(dst);
            this.length = length;
            this.available = true;
        }
    }


    private class CrossConnect{

        public String node_id;
        public String device_id;
        public List t_ports = new ArrayList();
        public List r_ports = new ArrayList();

        CrossConnect(Port port, OchPort och){
            this.t_ports.add(port.number().toString());
            this.r_ports = this.t_ports;

        }

        private void setNodeID(String s1){
          this.node_id = s1;
        }

        private void setDeviceID(String s1){
          this.device_id = s1;
        }

    }

    // This class is used to get all the transponders and regenerators
    private class NodeExistingDevices{

        public List transponders = new ArrayList();
        //public List regenerators = new ArrayList();

    }


    // This method is used to collect all the necessary information
    private class CollectAllInfo{

        public List optical_nodes = new ArrayList();
        public List ip_nodes = new ArrayList();
        public List optical_links = new ArrayList();
        public List existing_devices = new ArrayList();
        public List established_connections = new ArrayList();

        // THis build will generate the JSONSchema with all the information that has been collected from ONOS
        public void build(){

            optical_nodes = availableOpticalNodes;
            ip_nodes = availablePacketNodes;

            // Adding all the possible optical links in the current topology
            Iterator<Link> link_it = availableOpticalLinks.iterator();

            while( link_it.hasNext() ){
                Link link = link_it.next();
                optical_links.add(new TopoLink(link.src().deviceId().toString(), link.dst().deviceId().toString(), 120));
            }

            // Adding all the optical nodes in the topology.
            Iterator<String> node_iterator = opticalNodeIds.iterator();
            while( node_iterator.hasNext() ){

                String node_id = node_iterator.next();
                Collection<CrossConnect> node_optical_ports = opticalNodeCrossConnects.get(node_id);
                NodeExistingDevices e = new NodeExistingDevices();
                Iterator<CrossConnect> cc_it = node_optical_ports.iterator();

                while( cc_it.hasNext() ){
                    CrossConnect cc = cc_it.next();
                    e.transponders.add(cc);
                }


                existing_devices.add(e);

            }

        }

    // END OF CollectAllInfo Class

  }

  // This class will be used to generate the JSONSchema for Network_Topology paramater that is required by mantis.
  private class NetworkTopologyInfo{

    public List optical_nodes = new ArrayList();
    public List ip_nodes = new ArrayList();
    public List optical_links = new ArrayList();

    private void build2() {
      optical_nodes = availableOpticalNodes;
      ip_nodes = availablePacketNodes;
      Iterator<Link> link_it = availableOpticalLinks.iterator();
      while( link_it.hasNext() ){
          Link link = link_it.next();
          optical_links.add(new TopoLink(link.src().deviceId().toString(), link.dst().deviceId().toString(), 120));
        }
      }
    }



    // This class will be used to generate the JSONSchema for Nodes_Devices paramater that is required by mantis.
    private class NodesDevicesInfo{


      public List transponders = new ArrayList();
      public List regenerators = new ArrayList();
      int counter;

      // Adding all the optical nodes in the topology.
      public void build3(){
        String currentNode_ID = null;
        String previousNode_ID = null;
        String node_id;

        Iterator<String> node_iterator = opticalNodeIds.iterator();
        while( node_iterator.hasNext() ){
          node_id = node_iterator.next();
          log.info("The current Node is " + node_id);
          Collection<CrossConnect> node_optical_ports = opticalNodeCrossConnects.get(node_id);

          Iterator<CrossConnect> cc_it = node_optical_ports.iterator();
          while( cc_it.hasNext() ){

            currentNode_ID = node_id;
            log.info("the current Node is " + currentNode_ID);

              CrossConnect cc = cc_it.next();
              cc.setNodeID(node_id);
              cc.setDeviceID("201");


            transponders.add(cc);

            log.info("the previous Node is " + previousNode_ID);
            previousNode_ID = currentNode_ID;

            counter = counter+1;
            if (counter>10){
              break;
            }
          }
        }
      }
    }

    private class EstablishedConnections {
      public List optical_connections = new ArrayList();
      public List traffic_to_connections = new ArrayList();

    }

  // END OF TopologyManager
}

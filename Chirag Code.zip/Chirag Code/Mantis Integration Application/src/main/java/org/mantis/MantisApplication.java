// Most of this code has been writting in the similar style that is found in https://github.com/opennetworkinglab/onos/blob/master/core/net/src/main/java/org/onosproject/net/host/impl/HostManager.java

// This application has the following functions
//    1. Collect all the required information from ONOS and store it in an instance of the TopologyManager classes
//    2. Send this information in the JSON format to MantisApplication
//    3. Receive the path information that has been sent by Mantis
//    4. Program the new paths into ONOS
package org.mantis;



import com.google.common.collect.ImmutableSet;
import org.apache.felix.scr.annotations.*; // The * is used to import all the sub-classes in this main class
import org.onosproject.net.*;
import org.onosproject.net.device.DeviceService;
import org.onosproject.net.device.DeviceEvent;
import org.onosproject.net.device.DeviceListener;



import org.onosproject.net.intent.IntentEvent;
import org.onosproject.net.intent.IntentListener;
import org.onosproject.net.intent.IntentService;

// Importing all the libraries for links
import org.onosproject.net.link.LinkEvent;
import org.onosproject.net.link.LinkService;

// Importing all the libraries for topology
import org.onosproject.net.topology.TopologyEvent;
import org.onosproject.net.topology.TopologyListener;
import org.onosproject.net.topology.TopologyService;

// Libraries to enable logging functions
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

// Importing the libraries for the optical layer
import static org.onosproject.net.optical.device.OpticalDeviceServiceView.opticalView;
import org.onosproject.newoptical.OpticalConnectivity;
import org.onosproject.newoptical.api.OpticalPathService;

// Libraries for REST API
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.POST;


@Component(immediate = true)
public class MantisApplication {

    // Enable logging functionality for error reporting and debugging
    private final Logger log = LoggerFactory.getLogger(getClass());

    // cardinality annotation is used here to get the latest updates from onos
    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected TopologyService topologyService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected DeviceService deviceService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected LinkService linkService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    OpticalPathService opticalPathService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected IntentService intentService;

    // The final command is used to prevent the use of @Override from another class in the application.
    private final TopologyListener topologyListener = new InternalTopologyListener();
    private final DeviceListener deviceListener = new InternalDeviceListener();
    private final IntentListener intentListener = new InternalIntentListener();

    private TopologyManager topologyManager;

    @Activate
    protected void activate() {

        log.info("Mantis Application has Started");
        topologyManager = new TopologyManager();
        deviceService =  opticalView(deviceService);
        loadTopologyAndCurrentState();
        String schema = topologyManager.generateInternalJSONSchema();
        Client client = ClientBuilder.newClient();
        WebTarget myResource = client.target("http://147.102.22.142:8080/network_state");
        Response response = myResource.request(MediaType.APPLICATION_JSON).post(Entity.json(schema));
        log.info("Response /network_state =>  {} - {}", response.getStatus(), response.getStatusInfo().getReasonPhrase());

    }

    @Deactivate
    protected void deactivate() {

        log.info("Stopped");
    }

    private void loadTopologyAndCurrentState(){

        Iterable<Link> links;

        Iterable<Device> devices = deviceService.getDevices(Device.Type.ROADM);

        for( Device dev: devices)
            topologyManager.addOpticalNode(dev.id(), deviceService.isAvailable(dev.id()));

        for ( Device dev: devices ) {

            links = linkService.getDeviceLinks(dev.id());

            for (Link link : links)
                topologyManager.handleDeviceOpticalLink(dev.id().toString(), link);


            List<Port> ports = deviceService.getPorts(dev.id())
                    .stream()
                    .filter((p) -> p.type() == Port.Type.OCH)
                    .collect(Collectors.toList());

            topologyManager.handleCrossConnectionsPoints(dev.id().toString(), ports);
        }

        Collection<OpticalConnectivity> connections = opticalPathService.listConnectivity();

        topologyManager.handleEstablishedConnections(connections);

    }

    private class InternalDeviceListener implements  DeviceListener{

        @Override
        public void event(DeviceEvent event){

            Device dev = event.subject();

        }
    }

    //TODO: annotations used for temporarily later projection/network config will be used
    private class InternalTopologyListener implements TopologyListener {

        @Override
        public void event(TopologyEvent event) {

            event.reasons().forEach(e -> {

                if ( e instanceof  DeviceEvent ){

                    DeviceEvent deviceEvent = (DeviceEvent) e;

                    Device device = deviceEvent.subject();

                    log.error("------------------------");
                    log.error("DeviceEvent.Type = {}", deviceEvent.type());
                    log.error("------------------------");

                }

                //If event type is link removed, get the impacted tunnel
                if (e instanceof LinkEvent) {

                    LinkEvent linkEvent = (LinkEvent) e;

                    Link link = linkEvent.subject();

                    log.error("------------------------");
                    log.error("LinkEvent.Type = {}", linkEvent.type());
                    log.error("------------------------");
                }
            });

        }
    }

    public class InternalIntentListener implements IntentListener {
        @Override
        public void event(IntentEvent event) {
            switch (event.type()) {
                case INSTALLED:
                    log.error("Intent {} installed.", event.subject());
                    break;
                case WITHDRAWN:
                    log.error("Intent {} withdrawn.", event.subject());
                    break;
                case FAILED:
                    log.error("Intent {} failed.", event.subject());
                    break;
                default:
                    break;
            }
        }
    }

}

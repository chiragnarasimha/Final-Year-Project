#!/bin/bash

mvn clean install -Dmaven.test.skip=true


echo ""
onos-app localhost reinstall org.mantis.onos target/mantis-onos-1.0-SNAPSHOT.oar

# The current location of static paramaters: /home/onos/Desktop/Static_Paramaters.txt

mvn clean install -Dmaven.test.skip=true; onos-app localhost reinstall org.mantis.onos target/mantis-onos-1.0-SNAPSHOT.oar;
